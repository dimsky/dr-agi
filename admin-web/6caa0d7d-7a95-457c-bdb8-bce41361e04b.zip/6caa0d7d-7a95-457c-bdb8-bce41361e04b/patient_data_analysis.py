#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
沈树权患者检查报告数据分析
患者信息：77岁男性，心脏中心ICU患者
"""

import pandas as pd
import numpy as np
import json
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import rcParams

# 设置中文字体
rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
rcParams['axes.unicode_minus'] = False

def parse_datetime(date_str):
    """解析日期时间字符串"""
    try:
        return datetime.strptime(date_str, '%Y-%m-%d %H:%M')
    except:
        return datetime.strptime(date_str, '%Y-%m-%d')

# 患者基本信息
patient_info = {
    "name": "沈树权",
    "gender": "男",
    "age": 77,
    "hospital": "福建医科大学附属协和医院(旗山院区)",
    "department": "心脏中心ICU / 旗山心外科",
    "bed_number": "ICU016",
    "case_number": "1528474"
}

# 整理所有检测数据 - 按时间顺序
lab_data = [
    # 2025-08-26 21:46-21:48
    {
        "datetime": "2025-08-26 21:48",
        "白细胞计数": 9.61,
        "中性粒细胞%": 92.30,
        "淋巴细胞%": 3.00,
        "血红蛋白": 95.0,
        "血小板计数": 92,
        "C反应蛋白": 127.43,
        "降钙素原": None,  # 未检测
        "肌酐": 147,
        "谷氨酸转移酶": 1123,
        "天冬氨酸转移酶": 355,
        "N端B型钠尿肽": 4294,
        "肌钙蛋白": 3.32,
        "乳酸": 1.4,
        "血糖": 8.1
    },
    
    # 2025-08-26 22:59 (凝血)
    {
        "datetime": "2025-08-26 22:59",
        "凝血酶原时间": 12.3,
        "活化部分凝血酶原时间": 36.5,
        "纤维蛋白原": 4.97,
        "D二聚体": 6.64
    },
    
    # 2025-08-27 12:47 (血液)
    {
        "datetime": "2025-08-27 12:47",
        "血糖": 12.5,
        "乳酸": 1.4
    },
    
    # 2025-08-28 03:29
    {
        "datetime": "2025-08-28 03:29",
        "白细胞计数": 9.21,
        "中性粒细胞%": 90.30,
        "淋巴细胞%": 4.20,
        "血红蛋白": 87.0,
        "血小板计数": 68,
        "降钙素原": 2.970,
        "肌酐": 124,
        "N端B型钠尿肽": 2470,
        "凝血酶原时间": 12.5,
        "活化部分凝血酶原时间": 53.3,
        "纤维蛋白原": 5.97
    },
    
    # 2025-08-29 03:00-03:05
    {
        "datetime": "2025-08-29 03:00",
        "白细胞计数": 9.20,
        "中性粒细胞%": 86.60,
        "淋巴细胞%": 4.40,
        "血红蛋白": 80.0,
        "血小板计数": 62,
        "C反应蛋白": 171.23,
        "N端B型钠尿肽": 2363,
        "降钙素原": 3.100,
        "肌钙蛋白": 1.77,
        "血糖": 10.3,
        "乳酸": 1.0
    },
    
    # 2025-09-01 03:45-03:46
    {
        "datetime": "2025-09-01 03:46",
        "白细胞计数": 15.80,
        "中性粒细胞%": 89.50,
        "淋巴细胞%": 2.00,
        "血红蛋白": 65.0,
        "血小板计数": 130,
        "C反应蛋白": 70.76,
        "凝血酶原时间": 17.6,
        "活化部分凝血酶原时间": 39.1,
        "纤维蛋白原": 5.75,
        "肌钙蛋白": 0.44,
        "N端B型钠尿肽": 7717,
        "降钙素原": 4.240,
        "肌酐": 178
    },
    
    # 2025-09-02 03:05
    {
        "datetime": "2025-09-02 03:05",
        "血糖": 6.9,
        "乳酸": 1.5,
        "肌钙蛋白": 0.28
    }
]

# 影像学检查数据
imaging_data = [
    {
        "datetime": "2025-08-27 09:13",
        "examination": "胸部X线",
        "findings": "左下肺叶慢性炎症，透析管近心端相当于T8-9椎间隙右前、T9椎体右前水平，主动脉硬化"
    },
    {
        "datetime": "2025-08-27 09:15",
        "examination": "心电图",
        "findings": "窦性心律，V1-V4异常Q波，左胸导联QRS波低电压，ST-T改变（V1-V4导联ST段呈弓背向上型抬高）"
    },
    {
        "datetime": "2025-08-27 14:52",
        "examination": "床边心脏彩超",
        "findings": "左、右室壁运动异常，左、右室整体收缩及舒张功能减退，心包积液(微量)"
    },
    {
        "datetime": "2025-08-28 14:21",
        "examination": "CT颅脑平扫",
        "findings": "右侧枕叶软化灶可能，双侧额顶叶及基底节区多发腔梗及缺血灶，皮层下动脉硬化性脑白质改变，脑萎缩"
    },
    {
        "datetime": "2025-08-30 11:22",
        "examination": "心电图",
        "findings": "窦性心律，V1-V4异常Q波，ST段改变，Q-Tc间期延长"
    }
]

# 微生物培养数据
microbiology_data = [
    {
        "datetime": "2025-08-27 07:56",
        "specimen": "痰",
        "organisms": [
            {"name": "鲍曼不动杆菌", "count": "2+", "resistance": "多重耐药"},
            {"name": "嗜麦芽窄食单胞菌", "count": "2+", "resistance": ""}
        ]
    }
]

def create_dataframe():
    """创建实验室检查数据框"""
    df_list = []
    
    for data in lab_data:
        row = {"datetime": parse_datetime(data["datetime"])}
        for key, value in data.items():
            if key != "datetime" and value is not None:
                row[key] = value
        df_list.append(row)
    
    df = pd.DataFrame(df_list)
    df = df.sort_values('datetime').reset_index(drop=True)
    return df

def analyze_trends(df):
    """分析各指标趋势"""
    trends = {}
    
    # 重要指标分析
    key_indicators = [
        "白细胞计数", "血红蛋白", "血小板计数", "降钙素原", 
        "肌酐", "N端B型钠尿肽", "肌钙蛋白", "乳酸", "C反应蛋白"
    ]
    
    for indicator in key_indicators:
        if indicator in df.columns:
            values = df[indicator].dropna()
            if len(values) >= 2:
                trend_direction = "上升" if values.iloc[-1] > values.iloc[0] else "下降"
                change_percent = ((values.iloc[-1] - values.iloc[0]) / values.iloc[0]) * 100
                
                trends[indicator] = {
                    "initial_value": float(values.iloc[0]),
                    "final_value": float(values.iloc[-1]),
                    "trend_direction": trend_direction,
                    "change_percent": round(change_percent, 2),
                    "max_value": float(values.max()),
                    "min_value": float(values.min()),
                    "measurements_count": len(values)
                }
    
    return trends

def clinical_interpretation():
    """临床解读"""
    interpretation = {
        "感染指标分析": {
            "白细胞计数": "初期9.61→最高15.80，提示感染加重",
            "中性粒细胞比例": "持续>86%，提示细菌感染",
            "降钙素原": "2.970→4.240，显著升高，提示严重细菌感染",
            "C反应蛋白": "127.43→171.23→70.76，先升高后下降，提示炎症反应"
        },
        
        "心脏功能指标": {
            "N端B型钠尿肽": "4294→7717，显著升高，提示心功能严重受损",
            "肌钙蛋白": "3.32→1.77→0.44，逐渐下降，提示心肌损伤在恢复",
            "心电图": "V1-V4异常Q波，ST段改变，提示前壁心肌梗死"
        },
        
        "肾功能指标": {
            "肌酐": "147→124→178，波动性升高，提示肾功能不稳定"
        },
        
        "血液系统指标": {
            "血红蛋白": "95.0→65.0，明显下降，提示贫血加重",
            "血小板计数": "92→62→130，先下降后回升，可能与感染、用药相关"
        },
        
        "代谢指标": {
            "血糖": "8.1→12.5→6.9，波动较大，需要血糖管理",
            "乳酸": "1.4→1.0→1.5，轻度升高，提示组织缺氧"
        }
    }
    
    return interpretation

def disease_progression_analysis():
    """疾病进展分析"""
    progression = {
        "入院初期(8月26-27日)": {
            "主要问题": ["急性心肌梗死", "心功能不全", "感染"],
            "关键指标": {
                "肌钙蛋白": "3.32（明显升高）",
                "N端B型钠尿肽": "4294（心衰）",
                "C反应蛋白": "127.43（炎症）"
            },
            "临床表现": "心肌梗死急性期，心功能受损"
        },
        
        "中期(8月28-29日)": {
            "主要问题": ["感染加重", "心功能持续受损", "贫血"],
            "关键指标": {
                "降钙素原": "2.970-3.100（感染加重）",
                "血红蛋白": "87.0→80.0（贫血加重）",
                "N端B型钠尿肽": "2470（仍高）"
            },
            "临床表现": "感染控制困难，心功能仍不稳定"
        },
        
        "后期(9月1-2日)": {
            "主要问题": ["严重感染", "心功能恶化", "多器官功能不稳定"],
            "关键指标": {
                "白细胞计数": "15.80（感染加重）",
                "N端B型钠尿肽": "7717（心衰恶化）",
                "血红蛋白": "65.0（严重贫血）",
                "肌钙蛋白": "0.44→0.28（心肌损伤缓解）"
            },
            "临床表现": "病情复杂，多系统受累"
        }
    }
    
    return progression

def main():
    """主分析函数"""
    print("开始分析沈树权患者检查报告...")
    
    # 创建数据框
    df = create_dataframe()
    print(f"共提取到 {len(df)} 个时间点的检测数据")
    
    # 分析趋势
    trends = analyze_trends(df)
    
    # 临床解读
    clinical_interp = clinical_interpretation()
    
    # 疾病进展分析
    disease_prog = disease_progression_analysis()
    
    # 准备输出数据
    analysis_result = {
        "patient_info": patient_info,
        "analysis_summary": {
            "总体评估": "77岁男性患者，诊断急性心肌梗死合并心功能不全、严重感染、多器官功能受损",
            "主要问题": [
                "急性前壁心肌梗死（心电图V1-V4异常Q波）",
                "严重心功能不全（NT-proBNP显著升高）",
                "严重细菌感染（PCT升高，培养出多重耐药菌）",
                "贫血（血红蛋白进行性下降）",
                "肾功能不稳定（肌酐波动）"
            ],
            "预后评估": "病情危重，需要密切监护和积极治疗"
        },
        "time_series_data": df.to_dict('records'),
        "trend_analysis": trends,
        "clinical_interpretation": clinical_interp,
        "disease_progression": disease_prog,
        "imaging_findings": imaging_data,
        "microbiology_results": microbiology_data,
        "recommendations": {
            "感染控制": [
                "根据药敏结果调整抗生素方案",
                "监测PCT和CRP变化",
                "注意多重耐药菌感染"
            ],
            "心功能管理": [
                "密切监测NT-proBNP和肌钙蛋白",
                "心功能支持治疗",
                "监测心律和血压"
            ],
            "其他管理": [
                "纠正贫血，必要时输血",
                "肾功能保护",
                "血糖控制",
                "营养支持"
            ]
        }
    }
    
    # 保存结果到JSON文件
    output_file = "/tmp/claude_sandbox/workspace/5e6363c0-ecda-4426-8179-b43182a57055/6caa0d7d-7a95-457c-bdb8-bce41361e04b/patient_analysis_result.json"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(analysis_result, f, ensure_ascii=False, indent=2, default=str)
    
    print(f"分析结果已保存到: {output_file}")
    
    # 输出关键发现
    print("\n=== 关键临床发现 ===")
    print("1. 急性心肌梗死：肌钙蛋白峰值3.32，心电图V1-V4异常Q波")
    print("2. 严重心衰：NT-proBNP从4294升至7717 pg/ml")
    print("3. 严重感染：PCT升至4.240，培养出多重耐药鲍曼不动杆菌")
    print("4. 进行性贫血：血红蛋白从95降至65 g/L")
    print("5. 肾功能不稳定：肌酐在124-178 μmol/L波动")
    
    return analysis_result

if __name__ == "__main__":
    result = main()