#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
沈树权患者医学报告PDF生成器
"""

from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm, inch
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
import os
from datetime import datetime

class PatientReportGenerator:
    def __init__(self, filename="沈树权患者医学报告.pdf"):
        self.filename = filename
        self.doc = SimpleDocTemplate(
            filename,
            pagesize=A4,
            rightMargin=2*cm,
            leftMargin=2*cm,
            topMargin=2*cm,
            bottomMargin=2*cm
        )
        
        # 使用默认字体（支持中文）
        self.styles = getSampleStyleSheet()
        
        # 创建自定义样式
        self.title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=18,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=colors.HexColor('#2E86AB')
        )
        
        self.heading_style = ParagraphStyle(
            'CustomHeading',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=12,
            textColor=colors.HexColor('#A23B72')
        )
        
        self.normal_style = ParagraphStyle(
            'CustomNormal',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=6
        )
        
        self.story = []
    
    def add_header(self):
        """添加报告头部"""
        # 报告标题
        title = Paragraph("患者医学检验报告", self.title_style)
        self.story.append(title)
        self.story.append(Spacer(1, 20))
        
        # 患者基本信息
        patient_info = [
            ['患者信息', '', '', ''],
            ['姓名：沈树权', '性别：男', '年龄：77岁', ''],
            ['医院：福建医科大学附属协和医院(旗山院区)', '', '', ''],
            ['科室：心脏中心ICU / 旗山心外科(病房)', '', '', ''],
            ['医生：俞灵力 / 林昌城', '床号：ICU016', '病案号：1528474', ''],
            ['报告生成时间：' + datetime.now().strftime("%Y-%m-%d %H:%M:%S"), '', '', '']
        ]
        
        patient_table = Table(patient_info, colWidths=[4*cm, 4*cm, 4*cm, 4*cm])
        patient_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (3, 0), colors.HexColor('#F8F4E6')),
            ('TEXTCOLOR', (0, 0), (3, 0), colors.HexColor('#2E86AB')),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('GRID', (0, 0), (-1, -1), 1, colors.grey),
            ('SPAN', (0, 2), (3, 2)),  # 医院信息跨列
            ('SPAN', (0, 3), (3, 3)),  # 科室信息跨列
            ('SPAN', (0, 5), (3, 5)),  # 报告时间跨列
        ]))
        
        self.story.append(patient_table)
        self.story.append(Spacer(1, 20))
    
    def add_key_indicators(self):
        """添加关键指标数据表"""
        heading = Paragraph("关键指标监测数据", self.heading_style)
        self.story.append(heading)
        
        # 指标数据
        indicators_data = [
            ['指标名称', '2025-08-26', '2025-08-28', '2025-08-29', '2025-09-01', '参考范围', '单位'],
            ['白细胞计数', '9.61', '9.21', '9.20', '15.80', '4.00-10.00', '10^9/L'],
            ['血红蛋白', '95.0', '87.0', '80.0', '65.0', '120.0-165.0', 'g/L'],
            ['血小板计数', '92', '68', '62', '130', '100-300', '10^9/L'],
            ['降钙素原', '—', '—', '—', '4.240', '<0.051', 'ng/mL'],
            ['NT-proBNP', '4294', '2470', '2363', '7717', '0-738', 'pg/ml'],
            ['肌钙蛋白', '3.32', '—', '1.77', '0.44', '0.000-0.36', 'ng/mL'],
            ['肌酐', '147', '124', '—', '178', '57-111', 'μmol/L'],
            ['C反应蛋白', '127.43', '—', '171.23', '70.76', '0-8.00', 'mg/L'],
        ]
        
        indicators_table = Table(indicators_data, colWidths=[2.5*cm, 1.8*cm, 1.8*cm, 1.8*cm, 1.8*cm, 2.2*cm, 1.5*cm])
        indicators_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2E86AB')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            # 异常值标红
            ('TEXTCOLOR', (1, 1), (4, 1), colors.red),  # 白细胞最后一个值
            ('TEXTCOLOR', (1, 2), (4, 2), colors.red),  # 血红蛋白都异常
            ('TEXTCOLOR', (1, 3), (3, 3), colors.red),  # 血小板前三个值
            ('TEXTCOLOR', (4, 4), (4, 4), colors.red),  # 降钙素原
            ('TEXTCOLOR', (1, 5), (4, 5), colors.red),  # NT-proBNP都异常
            ('TEXTCOLOR', (1, 6), (3, 6), colors.red),  # 肌钙蛋白前三个值
            ('TEXTCOLOR', (1, 7), (4, 7), colors.red),  # 肌酐都异常
            ('TEXTCOLOR', (1, 8), (4, 8), colors.red),  # C反应蛋白都异常
        ]))
        
        self.story.append(indicators_table)
        self.story.append(Spacer(1, 20))
    
    def add_clinical_assessment(self):
        """添加临床评估"""
        heading = Paragraph("病情评估与分析", self.heading_style)
        self.story.append(heading)
        
        assessments = [
            "1. 急性前壁心肌梗死：",
            "   • 肌钙蛋白峰值达3.32 ng/mL（严重超标）",
            "   • 心电图显示V1-V4异常Q波，ST段改变",
            "   • 当前肌钙蛋白呈下降趋势，提示急性期已过",
            "",
            "2. 严重心功能不全：",
            "   • NT-proBNP从4294升至7717 pg/ml，提示心衰恶化",
            "   • 心超显示左右室壁运动异常，整体收缩及舒张功能减退",
            "   • 微量心包积液",
            "",
            "3. 严重感染状态：",
            "   • 降钙素原高达4.240 ng/mL（极度异常）",
            "   • 痰培养阳性：多重耐药鲍曼不动杆菌、嗜麦芽窄食单胞菌",
            "   • C反应蛋白持续升高（70.76-171.23 mg/L）",
            "",
            "4. 血液系统异常：",
            "   • 进行性贫血，血红蛋白从95降至65 g/L",
            "   • 血小板计数波动，最低至62×10^9/L",
            "",
            "5. 多器官功能受损：",
            "   • 肾功能不稳定：肌酐124-178 μmol/L",
            "   • 脑梗死：CT显示双侧额顶叶及基底节区多发腔梗",
            "   • 肺部感染伴支气管扩张"
        ]
        
        for assessment in assessments:
            para = Paragraph(assessment, self.normal_style)
            self.story.append(para)
        
        self.story.append(Spacer(1, 20))
    
    def add_timeline(self):
        """添加诊疗时间轴"""
        heading = Paragraph("诊疗时间轴", self.heading_style)
        self.story.append(heading)
        
        timeline_data = [
            ['时间', '重要检查/事件'],
            ['2025-08-26 21:46', '入院首次血液检查，发现心肌梗死'],
            ['2025-08-27 09:13', '胸部X线：左下肺叶慢性炎症'],
            ['2025-08-27 09:15', '心电图：V1-V4异常Q波，ST-T改变'],
            ['2025-08-27 14:52', '心脏彩超：左右室功能减退，心包积液'],
            ['2025-08-27 19:56-20:04', '四肢血管彩超：动脉粥样硬化'],
            ['2025-08-28 14:21', 'CT：脑梗死，肺部感染，心包积液'],
            ['2025-09-01 03:45', '降钙素原峰值，感染加重'],
            ['2025-09-02', '病情趋于稳定，但仍需密切监护']
        ]
        
        timeline_table = Table(timeline_data, colWidths=[3.5*cm, 10*cm])
        timeline_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#A23B72')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        
        self.story.append(timeline_table)
        self.story.append(Spacer(1, 20))
    
    def add_recommendations(self):
        """添加治疗建议"""
        heading = Paragraph("治疗建议", self.heading_style)
        self.story.append(heading)
        
        recommendations = [
            "1. 紧急处理：",
            "   • 继续抗感染治疗，根据药敏结果调整抗生素方案",
            "   • 强心利尿，改善心功能",
            "   • 纠正贫血，必要时输血",
            "",
            "2. 持续监测：",
            "   • 每日监测心肌标志物、NT-proBNP变化",
            "   • 密切观察感染指标（PCT、CRP、白细胞）",
            "   • 定期复查肾功能、肝功能",
            "   • 血常规监测，关注血红蛋白和血小板变化",
            "",
            "3. 综合治疗：",
            "   • 多学科协作：心内科、感染科、肾内科会诊",
            "   • 营养支持，改善一般状况",
            "   • 预防血栓，但需权衡出血风险",
            "   • 康复治疗，预防并发症",
            "",
            "4. 预后评估：",
            "   • 病情危重，涉及多个重要器官系统",
            "   • 需要长期监护和治疗",
            "   • 家属应做好充分的心理准备"
        ]
        
        for rec in recommendations:
            para = Paragraph(rec, self.normal_style)
            self.story.append(para)
    
    def generate_pdf(self):
        """生成PDF报告"""
        self.add_header()
        self.add_key_indicators()
        self.add_clinical_assessment()
        self.add_timeline()
        self.add_recommendations()
        
        # 构建PDF
        self.doc.build(self.story)
        print(f"PDF报告已生成：{self.filename}")

if __name__ == "__main__":
    generator = PatientReportGenerator()
    generator.generate_pdf()